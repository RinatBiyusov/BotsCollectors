    public class SetFlagCommand : ICommand
    {
        public void Execute()
        {
            
        }
    }
