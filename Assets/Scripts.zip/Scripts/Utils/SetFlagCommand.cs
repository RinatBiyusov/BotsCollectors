    public class SetFlagCommand : ICommand
    {
        public void Execute()
        {
            throw new System.NotImplementedException();
        }
    }
