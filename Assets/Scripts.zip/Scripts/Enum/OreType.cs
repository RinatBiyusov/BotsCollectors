public enum OreType
{
    Copper, 
    Coal,
    Gold
}