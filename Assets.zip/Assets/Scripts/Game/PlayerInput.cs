using System;
using UnityEngine;
using UnityEngine.XR;

public class PlayerInput : MonoBehaviour
{
    public event Action LeftButtonClicked;
    public event Action RightButtonClicked;

    private void Update()
    {
        HandleButtonClick();
    }
    
    private void HandleButtonClick()
    {
        if (Input.GetMouseButtonDown(0))
            LeftButtonClicked?.Invoke();

        if (Input.GetMouseButtonDown(1))
            RightButtonClicked?.Invoke();
    }
}