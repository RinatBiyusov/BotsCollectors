using UnityEngine;

public class Flag : MonoBehaviour
{
    public void MoveFlag(Vector3 newPosition)
    {
        transform.position = newPosition;
    }
}