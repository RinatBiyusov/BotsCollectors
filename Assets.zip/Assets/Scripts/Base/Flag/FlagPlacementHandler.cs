using UnityEngine;

public class FlagPlacementHandler : MonoBehaviour
{
    [SerializeField] private GameObject _flagPrefab;
    [SerializeField] private LayerMask _groundMask;

    private Base _currentBase;
    private bool _isPlacingFlag = false;
    
    private void Update()
    {
        if (!_isPlacingFlag)
            return;

        if (Input.GetMouseButtonDown(1))
            CancelPlacement();

        if (Input.GetMouseButtonDown(0))
            TryPlaceFlag();
    }
    
    public void StartPlacingFlag(Base targetBase)
    {
        _currentBase = targetBase;
        _isPlacingFlag = true;
    }

    private void TryPlaceFlag()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hitInfo, 100f, _groundMask))
        {
            Vector3 position = hitInfo.point;

            if (_currentBase.CurrentFlag == null)
            {
                Flag newFlag = Instantiate(_flagPrefab, position, Quaternion.identity).GetComponent<Flag>();
                _currentBase.SetFlag(newFlag);
            }
            else
                _currentBase.CurrentFlag.MoveFlag(position);

            _isPlacingFlag = false;
        }
    }

    private void CancelPlacement() =>
        _isPlacingFlag = false;
}